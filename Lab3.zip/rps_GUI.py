import pygame
import random
import sys
import time

pygame.init()
SCREEN_WIDTH, SCREEN_HEIGHT = 640, 480
BG_COLOR = (255, 255, 255)
FONT_COLOR = (0, 0, 0)
FONT_SIZE = 24
OPTIONS = ["Rock", "Paper", "Scissors"]
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Rock Paper Scissors Game")
font = pygame.font.Font(None, FONT_SIZE)
images = {
    'Rock': pygame.image.load('rps_GUI/rock.png'),
    'Paper': pygame.image.load('rps_GUI/paper.png'),
    'Scissors': pygame.image.load('rps_GUI/scissors.PNG'),
    'Victory': pygame.image.load('rps_GUI/victory.png'),
    'Loser': pygame.image.load('rps_GUI/loser.png')
}
def get_computer_choice():
    return random.choice(OPTIONS)
def determine_winner(user_choice, computer_choice):
    if user_choice == computer_choice:
        return 'Draw'
    elif (user_choice == 'Rock' and computer_choice == 'Scissors') or \
         (user_choice == 'Scissors' and computer_choice == 'Paper') or \
         (user_choice == 'Paper' and computer_choice == 'Rock'):
        return 'Win'
    else:
        return 'Lose'
def display_instructions():
    instructions = [
        "Press 'R' for Rock",
        "Press 'P' for Paper",
        "Press 'S' for Scissors",
        "Press 'Q' to Quit"
    ]
    y = 10
    for line in instructions:
        text = font.render(line, True, FONT_COLOR)
        screen.blit(text, (10, y))
        y += FONT_SIZE
def game_loop():
    running = True
    while running:
        screen.fill(BG_COLOR)
        display_instructions()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    user_choice = 'Rock'
                elif event.key == pygame.K_p:
                    user_choice = 'Paper'
                elif event.key == pygame.K_s:
                    user_choice = 'Scissors'
                elif event.key == pygame.K_q:
                    running = False
                else:
                    continue
                user_image = images[user_choice]
                screen.blit(user_image, (50, SCREEN_HEIGHT - user_image.get_height() - 100))
                computer_choice = get_computer_choice()
                comp_image = images[computer_choice]
                screen.blit(comp_image, (SCREEN_WIDTH - comp_image.get_width() - 50, SCREEN_HEIGHT - comp_image.get_height() - 100))

                pygame.display.flip()
                result = determine_winner(user_choice, computer_choice)
                time.sleep(1)  
                result_image = images['Victory'] if result == 'Win' else images['Loser']
                if result != 'Draw':
                    screen.blit(result_image, ((SCREEN_WIDTH - result_image.get_width()) // 2, (SCREEN_HEIGHT - result_image.get_height()) // 2))
                    pygame.display.flip()
                    time.sleep(2)  
        pygame.display.flip()
    pygame.quit()
    sys.exit()
game_loop()