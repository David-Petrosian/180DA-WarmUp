import paho.mqtt.client as mqtt

broker_address = "mqtt.eclipseprojects.io"
port = 1883

choices = {'client1': None, 'client2': None}
results = {'Client1 wins': 0, 'Client2 wins': 0, 'Tie': 0} 

def on_connect(client, userdata, flags, rc):
    print("Connected with result code " + str(rc))
    client.subscribe("rps/client1/choice")
    client.subscribe("rps/client2/choice")

def on_message(client, userdata, msg):
    client_id = msg.topic.split('/')[1]
    choice = msg.payload.decode()
    print(f"{client_id} chose {choice}")
    choices[client_id] = choice

    if all(choices.values()):
        winner = determine_winner(choices['client1'], choices['client2'])
        print("Winner:", winner)
        results[winner] += 1  
        print("Results:", results)  
        client.publish("rps/client1/result", winner)
        client.publish("rps/client2/result", winner)
        choices['client1'], choices['client2'] = None, None

def determine_winner(choice1, choice2):
    if choice1 == choice2:
        return "Tie"
    elif (choice1 == "rock" and choice2 == "scissors") or \
         (choice1 == "scissors" and choice2 == "paper") or \
         (choice1 == "paper" and choice2 == "rock"):
        return "Client1 wins"
    else:
        return "Client2 wins"

server = mqtt.Client()
server.on_connect = on_connect
server.on_message = on_message
server.connect(broker_address, port, 60)

server.loop_forever()
