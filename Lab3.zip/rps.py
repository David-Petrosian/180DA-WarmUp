import random

def get_computer_choice():
    return random.choice(['rock', 'paper', 'scissors'])

def determine_winner(user_choice, computer_choice):
    if user_choice == computer_choice:
        return 'draw'
    elif (user_choice == 'rock' and computer_choice == 'scissors') or \
         (user_choice == 'scissors' and computer_choice == 'paper') or \
         (user_choice == 'paper' and computer_choice == 'rock'):
        return 'win'
    else:
        return 'lose'

def main():
    results = {'win': 0, 'lose': 0, 'draw': 0}
    while True:
        user_choice = input("Enter rock, paper, or scissors (or 'quit' to stop): ").lower()
        if user_choice == 'quit':
            break
        if user_choice not in ['rock', 'paper', 'scissors']:
            print("Invalid input. Please choose 'rock', 'paper', or 'scissors'.")
            continue
        computer_choice = get_computer_choice()
        result = determine_winner(user_choice, computer_choice)
        results[result] += 1
        print(f"Your choice: {user_choice}, Computer's choice: {computer_choice}. You {result}!")
        print(f"Score - Wins: {results['win']}, Losses: {results['lose']}, Draws: {results['draw']}")
    print("Game over. Final Score - Wins: {}, Losses: {}, Draws: {}".format(results['win'], results['lose'], results['draw']))
if __name__ == "__main__":
    main()