import paho.mqtt.client as mqtt
import time

broker = "test.mosquitto.org"
port = 1883
client1_topic = "rps_game/client1"
client2_topic = "rps_game/client2"
client_id = "rps_client2"

client_choice = None
opponent_choice = None
choice_made = False
is_connected = False

def on_connect(client, userdata, flags, rc):
    global is_connected
    if rc == 0:
        print("Connected with result code " + str(rc))
        client.subscribe(client2_topic)
        is_connected = True
    else:
        print("Failed to connect, return code %d\n", rc)

def on_disconnect(client, userdata, rc):
    global is_connected
    is_connected = False
    print("Disconnected from MQTT Broker.")

def on_message(client, userdata, msg):
    global opponent_choice, choice_made
    if not choice_made:
        print(f"Opponent has made a choice.")
    else:
        opponent_choice = msg.payload.decode()
        print(f"Opponent chose: {opponent_choice}")

client = mqtt.Client(client_id)
client.on_connect = on_connect
client.on_disconnect = on_disconnect
client.on_message = on_message
client.connect(broker, port)
client.loop_start()

def determine_winner(choice1, choice2):
    if choice1 == choice2:
        return 'draw'
    elif (choice1 == 'rock' and choice2 == 'scissors') or \
         (choice1 == 'scissors' and choice2 == 'paper') or \
         (choice1 == 'paper' and choice2 == 'rock'):
        return 'win'
    else:
        return 'lose'

def main():
    global client_choice, choice_made, is_connected
    while not is_connected:
        time.sleep(1)  

    client_choice = input("Enter rock, paper, or scissors: ")
    client.publish(client2_topic, client_choice)
    choice_made = True

    print("Waiting for opponent...")
    while opponent_choice is None:
        time.sleep(1)

    result = determine_winner(client_choice, opponent_choice)
    print(f"You {result}! Your choice: {client_choice}, Opponent's choice: {opponent_choice}")

if __name__ == '__main__':
    main()