
import speech_recognition as sr

def recognize_speech_from_mic(recognizer, microphone):
    # Function to transcribe speech from the microphone
    if not isinstance(recognizer, sr.Recognizer):
        raise TypeError("`recognizer` must be `Recognizer` instance")

    if not isinstance(microphone, sr.Microphone):
        raise TypeError("`microphone` must be `Microphone` instance")

    with microphone as source:
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)

    response = {
        "success": True,
        "error": None,
        "transcription": None
    }

    try:
        response["transcription"] = recognizer.recognize_google(audio)
    except sr.RequestError:
        response["error"] = "API unavailable"
    except sr.UnknownValueError:
        response["error"] = "Unable to recognize speech"

    return response

def main():
    recognizer = sr.Recognizer()
    microphone = sr.Microphone()

    print("Please speak now...")
    speech = recognize_speech_from_mic(recognizer, microphone)

    if speech["error"]:
        print("ERROR: {}".format(speech["error"]))
    else:
        print("You said: {}".format(speech["transcription"]))

if __name__ == "__main__":
    main()
