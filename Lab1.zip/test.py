if __name__ == '__main__':
	x = "ECE_180_DA_DB"
	if x == "EE_180_DA_DB":
		print("You are living in 2017")
	else:
		# this is a comment
		x = x + " - Best class ever"
		print(x)